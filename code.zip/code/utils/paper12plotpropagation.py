# -*- coding: utf-8 -*-
"""
Created on Fri Jul 10 16:02:04 2020

@author: Oyelade
"""

import matplotlib.pyplot as plt
plt.style.use('seaborn-whitegrid')
import numpy as np


def _draw_propagation_rates__(data=None, compactments=None):
    indx=0
    for c in compactments:
        x = np.arange(len(data[indx][c]))
        plt.plot(x, data[indx][c], label=c)       
        indx+=1    
    plt.ylabel('Population')
    plt.xlabel('Epoch')
    plt.legend(loc='upper right')
    #handles, labels = plt.get_legend_handles_labels()
    #plt.legend(handles, labels, bbox_to_anchor =(0.75, 1.09), ncol = len(compactments))
    return None

'''
compactments=['I', 'R', 'D', 'H','V', 'S', 'Q']
history= [
{'I':   [85, 100, 14, 12, 10, 10, 10, 8, 7, 6, 4, 3, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]},
{'R':   [0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]},
{'D':   [0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]},
{'H':   [0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]},
{'V':   [0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]},
{'S':   [15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]},
{'Q':   [0, 2, 7, 11, 14, 18, 22, 22, 24, 24, 28, 31, 32, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33]}
       ]

_draw_propagation_rates__(history, compactments)
'''